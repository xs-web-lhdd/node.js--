const { createSecretKey } = require('crypto')
const http = require('http')

const serve = http.createServer((res, req) => {
    res.end('hello world')
})

serve.listen(8000)