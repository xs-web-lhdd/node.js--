const http = require('http')

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    const path = url.split('?')[0]  // 获取前面的列表
    const method = req.method

    // 写一个list的get的路由
    if(path === '/api/list' && method === 'GET') {
        // 返回结果
        const result = {
            error: 0,
            data: [
                { user: 'zhangsan',content: 'hello lisi' },
                { user: 'lisi',content: 'hi zhangsan'}
            ]
        }
        res.writeHead(200, {'ContentType':'application/json'})
        res.end( JSON.stringify(result) )
    }

    // 创建一个create的post的路由
    if(path === '/api/create' && method === 'POST') {

        let bodyStr = ''
        req.on('data', chuck => { // 服务端怎么识别“流”，并接受数据
            // chuck就是“流”的每一段数据
            bodyStr = bodyStr + chuck.toString()

        })

        req.on('end', () => { // 服务器怎么知道流完了
            // 验证是否是json格式：
            if(req.headers['content-type'] === 'application/json'){
                const body = JSON.parse(bodyStr)
                console.log('bodyStr is:',body)
            }

            res.end('stream is over')
        })
        // 要在这加上return否则会继续执行，那么postman中打印的就是下面的404格式的html了
        return 
    }

    // 没有命中路由
    res.writeHead(404, {'ContentType': 'text/plain'})
    res.end(`
    <!DOCTYPE html>
    <html>
        <head>
            <title>404</title>
        </head>
        <body>
            <h1>HELLO</h1>
        </body>
    </html>
    `)
})


server.listen(4000)
console.log('http 已经被监听，可以正常启用');