const http = require('http')

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    const path = url.split('?')[0]  // 获取前面的列表
    const queryStr = url.split('?')[1] // 获取queryString
    const method = req.method


    // const query = querystring.parse(queryStr)
    // console.log('query is:',query)





    // 写一个list的get的路由
    if(path === '/api/list' && method === 'GET') {
        if(query.filterType === '1'){
            res.end('this a list router,all')
        }
        if(query.filterType === '2'){
            res.end('this a list router,my')
        }
    }

    // 创建一个create的post的路由
    if(path === '/api/create' && method === 'POST') {
        res.end('this a create router')
    }

    res.end('test end')
})


server.listen(4000)
console.log('http 已经被监听，可以正常启用');