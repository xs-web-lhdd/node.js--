#### common.js与ES6.js的区别：

​	首先ES6是通过import引入文件的（在Vue中就能感受到），其次ES6暴露文件是通过export 或者 export default这种方式暴露的，如果文件中export使用了多次那么在import引入时要用 {a,b  } 这种方式将其引入，如果直接export default暴露出来可以直接 import a from '...'引进去。

​	而common.js是通过module.exports暴露出去的，通过require(...)引入文件的，主要应用于node.js开发

​	require比较强大它能区分三个层级：

```javascript
const http = require('http')		// 通过引用node自带的模块
const _ = require('lodash')			// 引入npm自带的包
const sum = require('./common.js')	// 引入自己定义的文件
```

还有一个非常重要的点就是common.js是动态的（可以在代码执行时引入）可以在if语句中执行，但是ES6就不行（ES6是静态的，在代码执行之前就把文件引进去了）

#### nodemon安装以及使用：

​		在命令行里输入npm i nodemon --save-dev，然后在pack.json里面配置"dev": "nodemon index.js"

以后在终端中执行npm run dev即可运行

#### 初试服务器：

```javascript
const http = require('http') // 引入http

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    res.end(url)
})


server.listen(4000) // 设置端口
console.log('http 已经被监听，可以正常启用');
```

#### 路由：

```javascript
const http = require('http')

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    const path = url.split('?')[0]  // 获取前面的列表
    const method = req.method

    // 写一个list的get的路由
    if(path === '/api/list' && method === 'GET') {
        res.end('this a list router')
    }

    // 创建一个create的post的路由
    if(path === '/api/create' && method === 'POST') {
        res.end('this a create router')
    }

    res.end('test end')
})


server.listen(4000)
console.log('http 已经被监听，可以正常启用');
```

这里测试post请求要用postman这个工具

#### querystring：

什么是querystring：www.https://xxxx.com/api/list?keyword=nab&lang=zn&a=10（举一个例子），其中？以后的就是querystring，也叫做url参数，通常以&进行分割，key=value形式，可继续扩展

介绍和使用：

```javascript
const http = require('http')

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    const path = url.split('?')[0]  // 获取前面的列表
    const queryStr = url.split('?')[1] // 获取queryString
    const method = req.method



    const query = {}
    queryStr && queryStr.split('&').forEach((item) => {
        const key = item.split('=')[0]
        const value = item.split('=')[1]
        query[key] = value
    })
    console.log(query)


    // 写一个list的get的路由 --- 根据不同的路由访问不同的页面（简陋版）
    if(path === '/api/list' && method === 'GET') {
        if(query.filterType === '1'){
            res.end('this a list router,all')
        }
        if(query.filterType === '2'){
            res.end('this a list router,my')
        }
    }

    // 创建一个create的post的路由
    if(path === '/api/create' && method === 'POST') {
        res.end('this a create router')
    }

    res.end('test end')
})


server.listen(4000)
console.log('http 已经被监听，可以正常启用');
```

#### res返回json格式数据：

```javascript
const http = require('http')

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    const path = url.split('?')[0]  // 获取前面的列表
    const method = req.method

    // 写一个list的get的路由
    if(path === '/api/list' && method === 'GET') {
        // 返回结果
        const result = {
            error: 0,
            data: [
                { user: 'zhangsan',content: 'hello lisi' },
                { user: 'lisi',content: 'hi zhangsan'}
            ]
        }
        res.writeHead(200, {'ContentType':'application/json'})
        res.end( JSON.stringify(result) )
    }

    // 创建一个create的post的路由
    if(path === '/api/create' && method === 'POST') {
        const result = {
            error: 0,
            message: '创建成功'
        }
        res.writeHead(200, {'ContentType': 'application/json'})
        res.end( JSON.stringify(result) )
    }

    // 没有命中路由
    res.writeHead(404, {'ContentType': 'text/plain'})
    res.end('404 Not Found')
})


server.listen(4000)
console.log('http 已经被监听，可以正常启用');
```

写完这些代码已经有点后端开发人员的感觉了

#### 返回HTML格式：

1、通过Content-Type设置为text/html 

2、res.end(...)

3、浏览器会根据Content-Type识别出html格式

举例：

```javascript
const http = require('http')

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    const path = url.split('?')[0]  // 获取前面的列表
    const method = req.method


    // 写一个list的get的路由
    if(path === '/api/list' && method === 'GET') {
        // 返回结果
        const result = {
            error: 0,
            data: [
                { user: 'zhangsan',content: 'hello lisi' },
                { user: 'lisi',content: 'hi zhangsan'}
            ]
        }
        res.writeHead(200, {'ContentType':'application/json'})
        res.end( JSON.stringify(result) )
    }

    // 创建一个create的post的路由
    if(path === '/api/create' && method === 'POST') {
        const result = {
            error: 0,
            message: '创建成功'
        }
        res.writeHead(200, {'ContentType': 'application/json'})
        res.end( JSON.stringify(result) )
    }

    // 没有命中路由
    res.writeHead(404, {'ContentType': 'text/plain'})
    res.end(`
    <!DOCTYPE html>
    <html>
        <head>
            <title>404</title>
        </head>
        <body>
            <h1>HELLO</h1>
        </body>
    </html>
    `)
})

server.listen(4000)
console.log('http 已经被监听，可以正常启用');
```

#### 获取Request Body：

```javascript
const http = require('http')

const server = http.createServer((req,res) => {
    console.log('已经收到http请求');
    const url = req.url
    const path = url.split('?')[0]  // 获取前面的列表
    const method = req.method

    // 写一个list的get的路由
    if(path === '/api/list' && method === 'GET') {
        // 返回结果
        const result = {
            error: 0,
            data: [
                { user: 'zhangsan',content: 'hello lisi' },
                { user: 'lisi',content: 'hi zhangsan'}
            ]
        }
        res.writeHead(200, {'ContentType':'application/json'})
        res.end( JSON.stringify(result) )
    }

    // 创建一个create的post的路由
    if(path === '/api/create' && method === 'POST') {

        let bodyStr = ''
        req.on('data', chuck => { // 服务端怎么识别“流”，并接受数据
            // chuck就是“流”的每一段数据
            bodyStr = bodyStr + chuck.toString()

        })

        req.on('end', () => { // 服务器怎么知道流完了
            // 验证是否是json格式：
            if(req.headers['content-type'] === 'application/json'){
                const body = JSON.parse(bodyStr)
                console.log('bodyStr is:',body)
            }

            res.end('stream is over')
        })
        // 要在这加上return否则会继续执行，那么postman中打印的就是下面的404格式的html了
        return 
    }

    // 没有命中路由
    res.writeHead(404, {'ContentType': 'text/plain'})
    res.end(`
    <!DOCTYPE html>
    <html>
        <head>
            <title>404</title>
        </head>
        <body>
            <h1>HELLO</h1>
        </body>
    </html>
    `)
})


server.listen(4000)
console.log('http 已经被监听，可以正常启用');
```

感觉很新奇啊！

# koa2:

路由相关基本操作：

1、创建路由：在routes内创建一个文件（例如：common.js）,在conmon.js里面进行配置：

```javascript
const router = require('koa-router')()

router.prefix('/api') // 定义路由前缀

// 1、定义路由 --- 模拟获取留言版列表
router.get('/list', async(ctx) => {
    ctx.body = 'api list'
})

// 2、定义路由 --- 模拟创建留言
router.post('/create', async(ctx) => {
    ctx.body = 'api create'
})


module.exports = router // 输出 --- 千万不要忘记了

```

2、在app.js里面声明路由（一般在引入文件的代码下面）：

```javascript
const common = require('./routes/common')
```

3、注册路由：

```javascript
app.use(common.routes(), common.allowedMethods())
```

##### koa2处理http请求：

```javascript
const router = require('koa-router')()

router.prefix('/api')

// 1、定义路由 --- 模拟获取留言版列表
router.get('/list', async(ctx) => {
    const query = ctx.query // query功能
    console.log('query:', query);
    // ctx.body = 'api list' // 以字符串的格式返回
    ctx.body = {          // 以json的方式返回 --- 虽然代码里没有显示json格式，但通过这种方式已经默认使用了json
        error: 0,
        data:[
            { content: '留言1',user: 'zhangsan' },
            { content: '留言2',user: 'lisi' },
            { content: '留言3',user: 'wangmazi' }
        ]
    }
})

// 2、定义路由 --- 模拟创建留言
router.post('/create', async(ctx) => {
    const body = ctx.request.body // request body
    console.log('body', body)
    // ctx.body = 'api create' // 字符串格式
    ctx.body = { // json格式
        error: 0,
        data:[
            { content: 'hello',user: 'zhangsan' },
            { content: 'world',user: 'lisi' },
            { content: 'liuhao',user: 'liuaho'}
        ]
    }
})


module.exports = router // 输出 --- 千万不要忘记了

```

koa2与原生比较，koa2明显方便许多，而且规范性更好，在写代码时快速开发，专注于业务代码，忽略一些细节的处理