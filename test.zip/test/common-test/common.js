const sum = require('./until')

const res = sum(10,20)


console.log(res);