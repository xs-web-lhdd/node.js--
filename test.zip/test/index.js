const http = require('http')

const server = http.createServer((req,res) => {
    const url = req.url
    const path = url.split('?')[0]
    res.end(path + '123')
} )

server.listen(3000)