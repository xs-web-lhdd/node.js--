const _ = require('lodash')

const arr = [1,2,3]
const otherArr = _.concat(arr,4,5)

console.log(otherArr)